////////////////////////////////задание 1///////////////////////////
document.write('<br> Задание 1 <br>');
document.write('<br> Почему код дает именно такие результаты? <br>');
var a = 1,
    b = 1,
    c, d;
c = ++a;
alert(c); // 2 1 + 1 = 2
d = b++;
alert(d); // 1 Постфиксная форма b++ отличается от префиксной ++b тем, что возвращает старое значение, бывшее до увеличения
c = (2 + ++a);
alert(c); // 5 2 + (1+2) 
d = (2 + b++);
alert(d); // 4  2 + 2 Постфиксная форма b++ отличается от префиксной ++b тем, что возвращает старое значение, бывшее до увеличения
alert(a); // 3
alert(b); // 3
document.write('<br> Постфиксная форма b++ отличается от префиксной ++b тем, что возвращает старое значение, бывшее до увеличения <br>');

////////////////////////////////задание 2///////////////////////////
document.write('<br> Задание 2 <br>');
document.write('<br> Чему будет равен x? <br>');

var a = 2;
var x = 1 + (a *= 2);
document.write('<br> a *= 2 - сокращенная запись работает как a = a * 2 x=' + x);

////////////////////////////////задание 3///////////////////////////
document.write('<br> Задание 3 <br>');

//Объявить две целочисленные переменные — a и b и задать им произвольные начальные значения. 
//Затем написать скрипт, который работает по следующему принципу:
//
//если a и b положительные, вывести их разность;
//если а и b отрицательные, вывести их произведение;
//если а и b разных знаков, вывести их сумму;
//Ноль можно считать положительным числом.


// Возвращает случайное число между min (включительно) и max (не включая max)
function getRandomArbitrary(min, max) {
    return Math.round(Math.random() * (max - min) + min);
}

// операции начало
function summ(a, b) {
    return (a + b);
}

function diff(a, b) {
    return (a - b);
}

function multiply(a, b) {
    return (a * b);
}

function split(a, b) {
    return (a / b);
}
// операции конец
//
function br() {
    document.write('<br>');
}


var min = -100;
var max = 101;
var a = getRandomArbitrary(min, max);
var b = getRandomArbitrary(min, max);
document.write('a=' + a + '<br>');
document.write('b=' + b + '<br>');

if ((a >= 0) && (b >= 0)) {
    //если a и b положительные, вывести их разность;
    document.write('a-b=' + diff(a, b) + '<br>');
} else if ((a < 0) && (b < 0)) {
    //если а и b отрицательные, вывести их произведение;
    document.write('a*b=' + multiply(a, b) + '<br>');
} else if ((a * b) < 0) {
    //если а и b разных знаков, вывести их сумму;
    document.write('a+b=' + summ(a, b) + '<br>');
}

////////////////////////////////задание 4///////////////////////////
document.write('<br> Задание 4 <br>');
document.write('<br> Присвоить переменной а значение в промежутке [0..15]. С помощью оператора switch организовать вывод чисел от a до 15. <br>');
var a = getRandomArbitrary(0, 16);

document.write('a=' + a);

switch (a) {
    case 1:
        br();
        document.write(1);
    case 2:
        br();
        document.write(2);
    case 3:
        br();
        document.write(3);
    case 4:
        br();
        document.write(4);
    case 5:
        br();
        document.write(5);
    case 6:
        br();
        document.write(6);
    case 7:
        br();
        document.write(7);
    case 8:
        br();
        document.write(8);
    case 9:
        br();
        document.write(9);
    case 10:
        br();
        document.write(10);
    case 11:
        br();
        document.write(11);
    case 12:
        br();
        document.write(12);
    case 13:
        br();
        document.write(13);
    case 14:
        br();
        document.write(14);
    case 15:
        br();
        document.write(15);
}

////////////////////////////////задание 5///////////////////////////
document.write('<br> Задание 5 <br>');
document.write('<br> сделано <br>');
//Реализовать четыре основные арифметические операции в виде функций с двумя параметрами. Обязательно использовать оператор return.
//выше реализованы функции  summ diff multiply split 

////////////////////////////////задание 6///////////////////////////
document.write('<br> Задание 6 <br>');
//Реализовать функцию с тремя параметрами:
//function mathOperation(arg1, arg2, operation), где arg1, arg2— значения аргументов, operation— строка с названием операции.
//В зависимости от переданного значения выполнить одну из арифметических операций(использовать функции из пункта 3) 
//и вернуть полученное значение(применить switch).

function mathOperation(arg1, arg2, operation) {
    br();
    document.write('a=' + arg1 + ' b=' + arg2);
    br();
    document.write('operation ' + operation)
    br();
    switch (operation) {
        case '+':
            document.write(summ(arg1, arg2));
            break;
        case '-':
            document.write(diff(arg1, arg2));
            break;
        case '*':
            document.write(multiply(arg1, arg2));
            break;
        case '/':
            document.write(split(arg1, arg2));
            break;
        default:
            document.write('не известная операция');
    }
}

var a = getRandomArbitrary(0, 16);
var b = getRandomArbitrary(0, 16);

mathOperation(a, b, '+');
mathOperation(a, b, '-');
mathOperation(a, b, '*');
mathOperation(a, b, '/');

////////////////////////////////задание 7///////////////////////////
document.write('<br> Задание 7 <br>');
document.write('<br> Сравнить null и 0. Объяснить результат. <br>');
if (null === 0) {
    document.write('Равны');
} else {
    document.write('не равны, так как ноль это число, а null это не число, это отсутствие типа');
}
////////////////////////////////задание 8///////////////////////////
document.write('<br> Задание 8 <br>');
// С помощью рекурсии организовать функцию возведения числа в степень. 
//Формат: function power(val, pow), где val — заданное число, pow –— степень.

function power(val, pow) {
    if (pow === 1) {
        return val;
    } else if (pow === 0) {
        return 1;
    } else {
        pow = pow - 1;
        return val * power(val, pow);
    }
}
var val = 2;
var pow = 5;
document.write('val= ' + val + ' pow= ' + pow + ' результат ' + power(val, pow));
